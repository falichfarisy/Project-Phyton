-- Create database with name="login_and_register"
create table data_user (
idUser int auto_increment primary key,
email varchar(100) not null,
namaUser varchar(100) not null,
password varchar(100) not null
);	
