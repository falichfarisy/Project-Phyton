from tkinter import * 
import mysql.connector
from tkinter import messagebox

def Getconnection():
    return mysql.connector.connect(
        host='localhost', port=3306, password='', db='Login_and_Register', user='root'
    )

def login():
    valid_user = emailbox.get()
    valid_password = passbox.get()
    try:
        conn = Getconnection()
        cursor = conn.cursor()
        query = "SELECT * FROM data_user WHERE email = %s AND password = %s"
        cursor.execute(query,(valid_user, valid_password))
        result = cursor.fetchone()
        if result:
            namaUser = result[2]
            messagebox.showinfo("Info", f"Selamat datang {namaUser}!")
        else:
            messagebox.showerror("error","Email atau password salah")
    except mysql.connector.errors as err:
        messagebox.showerror(f"terjadi kesalahan pada database:{err}", "atau terjadi kesalahan pada kode")

def register():
    email = emailbox.get()
    password = passbox.get()
    namaUser = namaregisterbox.get()
    try:
        conn = Getconnection()
        cursor = conn.cursor()
        data = (email, namaUser, password)
        query ="INSERT INTO data_user (email, namaUser, password) VALUES (%s, %s, %s)"
        cursor.execute(query, data)
        conn.commit()
        show_login_form()
    except mysql.connector.errors as err:
        messagebox.showerror("Database error", f"terjadi kesalahan pada:{err}")

def show_register_form():
    login_frame.grid_forget()
    registerf.grid(row=0, column=0)

def show_login_form():
    registerf.grid_forget()
    login_frame.grid(row=0, column=0)

root = Tk()
root.title("Login and Register")

#login
login_frame = Frame(root)
email = Label(login_frame, text='Email : ')
password = Label(login_frame, text='Password : ')
emailbox = Entry(login_frame)
passbox = Entry(login_frame, show='*')
Login_button = Button(login_frame, text='Login', command=login)
Register_button = Button(login_frame, text='Register', command=show_register_form)

email.grid(row=0, column=0)
emailbox.grid(row=0, column=1)
password.grid(row=1, column=0)
passbox.grid(row=1, column=1)
Login_button.grid(row=2, column=1, pady=10)
Register_button.grid(row=2, column=2, pady=10)

#register
registerf = Frame(root)
namaregistrasi = Label(registerf, text='Nama : ')
namaregisterbox = Entry(registerf)
email = Label(registerf, text='Email : ')
emailbox = Entry(registerf)
password = Label(registerf, text='Password : ')
passbox = Entry(registerf, show='*')
Register_button = Button(registerf, text='register', command=register)

namaregistrasi.grid(row=0, column=0)
namaregisterbox.grid(row=0, column=1)
email.grid(row=1, column=0)
emailbox.grid(row=1, column=1)
password.grid(row=2, column=0)
passbox.grid(row=2, column=1)
Register_button.grid(row=3, column=1)

show_login_form()

root.mainloop()